# IO.Swagger.Model.StationTotalStandsAvailabilities
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bikes** | **int?** |  | [optional] 
**Stands** | **int?** |  | [optional] 
**MechanicalBikes** | **int?** |  | [optional] 
**ElectricalBikes** | **int?** |  | [optional] 
**ElectricalInternalBatteryBikes** | **int?** |  | [optional] 
**ElectricalRemovableBatteryBikes** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

