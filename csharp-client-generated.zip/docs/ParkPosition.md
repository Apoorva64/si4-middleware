# IO.Swagger.Model.ParkPosition
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Latitude** | [**decimal?**](BigDecimal.md) |  | [optional] 
**Longitude** | [**decimal?**](BigDecimal.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

