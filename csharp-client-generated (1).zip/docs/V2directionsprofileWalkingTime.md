# IO.Swagger.Model.V2directionsprofileWalkingTime
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Seconds** | **long?** |  | [optional] 
**Nano** | **int?** |  | [optional] 
**Negative** | **bool?** |  | [optional] 
**Zero** | **bool?** |  | [optional] 
**Units** | [**List&lt;V2directionsprofileScheduleDurationUnits&gt;**](V2directionsprofileScheduleDurationUnits.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

