# IO.Swagger.Model.GeoJSONPropertiesObjectOsmTags
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Address** | **string** |  | [optional] 
**Website** | **string** |  | [optional] 
**OpeningHours** | **string** |  | [optional] 
**Wheelchair** | **string** |  | [optional] 
**Distance** | **string** |  | [optional] 
**Fee** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

