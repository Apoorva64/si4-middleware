# IO.Swagger.Model.JsonExportResponseWarning
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **int?** | Identification code for the warning | [optional] 
**Message** | **string** | The message associated with the warning | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

