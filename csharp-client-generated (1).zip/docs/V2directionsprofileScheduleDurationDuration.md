# IO.Swagger.Model.V2directionsprofileScheduleDurationDuration
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Seconds** | **long?** |  | [optional] 
**Nano** | **int?** |  | [optional] 
**Negative** | **bool?** |  | [optional] 
**Zero** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

