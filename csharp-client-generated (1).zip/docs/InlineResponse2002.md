# IO.Swagger.Model.InlineResponse2002
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nodes** | [**List&lt;JsonExportResponseNodes&gt;**](JsonExportResponseNodes.md) |  | [optional] 
**Edges** | [**List&lt;JsonExportResponseEdges&gt;**](JsonExportResponseEdges.md) |  | [optional] 
**EdgesExtra** | [**List&lt;JsonExportResponseEdgesExtra&gt;**](JsonExportResponseEdgesExtra.md) |  | [optional] 
**Warning** | [**JsonExportResponseWarning**](JsonExportResponseWarning.md) |  | [optional] 
**NodesCount** | **long?** |  | [optional] 
**EdgesCount** | **long?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

