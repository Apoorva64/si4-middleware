# IO.Swagger.Model.OpenpoiservicePoiResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** |  | [optional] [default to "FeatureCollection"]
**Features** | [**List&lt;GeoJSONFeaturesObject&gt;**](GeoJSONFeaturesObject.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

