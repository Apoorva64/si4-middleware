# IO.Swagger.Model.GeoJSONPropertiesObjectCategoryIdsCategoryId
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CategoryName** | **string** |  | [optional] 
**CategoryGroup** | [**decimal?**](BigDecimal.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

