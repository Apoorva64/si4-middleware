# IO.Swagger.Model.PoisFilters
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CategoryGroupIds** | **List&lt;long?&gt;** |  | [optional] 
**CategoryIds** | **List&lt;long?&gt;** |  | [optional] 
**Name** | **List&lt;string&gt;** | Filter by name of the poi object. | [optional] 
**Wheelchair** | **List&lt;string&gt;** | Filter example. | [optional] 
**Smoking** | **List&lt;string&gt;** | Filter example. | [optional] 
**Fee** | **List&lt;string&gt;** | Filter example. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

