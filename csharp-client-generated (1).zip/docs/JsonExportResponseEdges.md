# IO.Swagger.Model.JsonExportResponseEdges
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FromId** | **int?** | Id of the start point of the edge | [optional] 
**ToId** | **int?** | Id of the end point of the edge | [optional] 
**Weight** | **double?** | Weight of the corresponding edge in the given bounding box | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

