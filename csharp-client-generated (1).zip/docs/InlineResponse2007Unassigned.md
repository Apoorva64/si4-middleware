# IO.Swagger.Model.InlineResponse2007Unassigned
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | The &#x60;id&#x60; of the unassigned job\&quot; | [optional] 
**Location** | **List&lt;float?&gt;** | The &#x60;location&#x60; of the unassigned job | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

