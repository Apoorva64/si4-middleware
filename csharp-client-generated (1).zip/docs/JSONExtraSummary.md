# IO.Swagger.Model.JSONExtraSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | **double?** | [Value](https://GIScience.github.io/openrouteservice/documentation/extra-info/Extra-Info.html) of a info category. | [optional] 
**Distance** | **double?** | Cumulative distance of this value. | [optional] 
**Amount** | **double?** | Category percentage of the entire route. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

