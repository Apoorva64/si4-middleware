# IO.Swagger.Model.V2directionsprofileScheduleDurationUnits
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateBased** | **bool?** |  | [optional] 
**TimeBased** | **bool?** |  | [optional] 
**Duration** | [**V2directionsprofileScheduleDurationDuration**](V2directionsprofileScheduleDurationDuration.md) |  | [optional] 
**DurationEstimated** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

