# IO.Swagger.Model.JsonExportResponseEdgesExtra
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EdgeId** | **string** | Id of the corresponding edge in the graph | [optional] 
**Extra** | **Object** | Extra info stored on the edge | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

