# IO.Swagger.Model.InlineResponse2006
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Attribution** | **string** |  | [optional] 
**Version** | **string** |  | [optional] 
**Timestamp** | **int?** |  | [optional] 
**Geometry** | [**InlineResponse2006Geometry**](InlineResponse2006Geometry.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

