# IO.Swagger.Model.OptimizationOptions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**G** | **bool?** | Calculate geometries for the optimized routes. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

