# IO.Swagger.Model.GeoJSONFeaturesObject
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** |  | [optional] [default to "Feature"]
**Geometry** | [**GeoJSONGeometryObject**](GeoJSONGeometryObject.md) |  | [optional] 
**FeatureProperties** | [**GeoJSONPropertiesObject**](GeoJSONPropertiesObject.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

